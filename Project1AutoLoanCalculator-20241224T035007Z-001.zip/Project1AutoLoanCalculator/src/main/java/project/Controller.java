package project;

import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 * Name: Elizabeth Guo
 * Username: elizabethguo
 */

public class Controller {
	
	   @FXML
	   private TextField basePrice, downPayment, salesTax;
	   
	   @FXML
	   private Label loanAmount, monthlyPayment, totalPayment;
	   
	   @FXML
	   private RadioButton m24, m36, m48, m60;
	   
	   @FXML
	   private CheckBox sunRoof, touchScreen, rearCamera;
	  
	   public void calculate() {
		   
		   double optionCosts = 0.0;
		   double subTotal = 0.0;
		   double taxRate = 0.0;
		   double tax = 0.0;
		   double annualInterestRate = 0.0;
		   double monthlyInterest = 0.0;
		   double monthScale = 0.0;
		   int months = 0;
		   double loanAmountIN = 0.0;
		   double monthlyPaymentIN = 0.0;
		   double totalPaymentIN = 0.0;
		   
		   if (sunRoof.isSelected()) {
			   optionCosts += 1510.0;
		   }
		   if (touchScreen.isSelected()) {
			   optionCosts += 470.0;
		   }
		   if (rearCamera.isSelected()) {
			   optionCosts += 340.0;
		   }
		   
		   subTotal = Double.parseDouble(basePrice.getText()) + optionCosts;
		   
		   taxRate = Double.parseDouble(salesTax.getText()) * 0.01;
		   
		   tax = subTotal * taxRate;
		   
		   loanAmountIN = subTotal + tax - Double.parseDouble(downPayment.getText());
		   loanAmount.setText(String.format("%.2f", loanAmountIN));
		   
		   if (m24.isSelected()) {
			   annualInterestRate = 0.07;
			   months = 24;
		   } else if (m36.isSelected()) {
			   annualInterestRate = 0.06;
			   months = 36;
		   } else if (m48.isSelected()) {
			   annualInterestRate = 0.055;
			   months = 48;
		   } else if (m60.isSelected()) {
			   annualInterestRate = 0.05;
			   months = 60;
		   }
		   
		   monthlyInterest = annualInterestRate / 12;
		   monthScale = Math.pow(1 + monthlyInterest, months);
		   monthlyPaymentIN = loanAmountIN * ((monthlyInterest * monthScale) / (monthScale - 1));
		   monthlyPayment.setText(String.format("%.2f", monthlyPaymentIN));
		   
		   totalPaymentIN = monthlyPaymentIN * months;
		   totalPayment.setText(String.format("%.2f", totalPaymentIN));
		   
	   }
	   
	   public void reset() {
		   
		   loanAmount.setText("0.0");
		   monthlyPayment.setText("0.0");
		   totalPayment.setText("0.0");
	   	
		   m24.setSelected(true);
		   m36.setSelected(false);
		   m48.setSelected(false);
		   m60.setSelected(false);
	   	
		   basePrice.setText("0.0");
		   downPayment.setText("0.0");
		   salesTax.setText("7.0");
		   
		   sunRoof.setSelected(false);
		   touchScreen.setSelected(false);
		   rearCamera.setSelected(true);
		   
	   }
	}

