package lab;
public class CancelledSurveyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1488771130069213210L;

	public CancelledSurveyException() {
		super("Your survey was cancelled.");
	}
}
