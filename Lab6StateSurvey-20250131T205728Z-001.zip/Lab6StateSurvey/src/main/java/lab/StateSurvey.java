package lab;
import java.io.*;
import java.util.*;

public class StateSurvey {
	
	public static Scanner scanner = new Scanner(System.in);

	public static void main (String[] args) throws IOException {
		try { 
			System.out.println("Welcome to our survey. You may " + "enter \"quit\" at any time to cancel the survey."); 
			
			int age = getAge();
			String[][] states = readStateFile(); 
			String state = getState(states); 
			int ZIPCode = getZIPCode(); 
			
			System.out.printf("\nAge:\t\t%d\n", age); 
			System.out.printf("Address:\t%s %s\n\n", ZIPCode, state);
			
			System.out.println( "Your survey is complete!");
			
		} 
		catch (CancelledSurveyException e) { 
			System.out.println(e.getMessage());
		} 
		finally { 
			System.out.println("Thank you for your time.");
		}
	}
	
	public static String getResponseOrQuit() throws CancelledSurveyException{
		String response = scanner.nextLine();
		
		if(response.equalsIgnoreCase("quit")) {
			throw new CancelledSurveyException();
		} else {
			return response;
		}
	}
	
	public static int getAge() throws CancelledSurveyException {
		boolean validAge = false;
		int age = -1;
		
		while(!validAge) {
			try {
				System.out.print("Enter your age: ");
				String response = getResponseOrQuit();
				age = Integer.parseInt(response);
				if(age >= 18) {
					validAge = true;
				} else if(age >= 0 && age < 18) {
					System.out.println("You are too young to complete the survey.");
					throw new CancelledSurveyException();
				}
			}
			catch (NumberFormatException except) {
				System.out.print("You've entered an invalid age. ");
			}
		}
		
		return age;
	}
	
	public static int getZIPCode() throws CancelledSurveyException {
		boolean validZip = false;
		int zipCode = -1;
		
		while(!validZip) {
			try {
				System.out.print("Please enter your zip code: ");
				String response = getResponseOrQuit();
				zipCode = Integer.parseInt(response);
				if(zipCode >= 10000 && zipCode <= 99999) {
					validZip = true;
				} else if(zipCode <= 10000 || zipCode >= 99999) {
					System.out.println("Invalid ZIP Code.");
				}
			}
			catch (NumberFormatException except) {
				System.out.print("Invalid ZIP code.");
			}
		}
		
		return zipCode;
	}
	
	public static String[][] readStateFile() throws IOException {
		String[][] statesBinFile = new String[50][2];
		int rowNum = 0;
		int colNum = 0;
		String current = "";
		
		FileInputStream fstream = 
				new FileInputStream("states.bin");
		DataInputStream inputFile = 
				new DataInputStream(fstream);
		
		/* while (!endOfFile)
	      {
	         try
	         {
	            current = inputFile.readUTF();
	            statesBinFile[rowNum][colNum] = current;
	            if(colNum == 0) {
	            	colNum++;
	            } else if (colNum == 1){
	            	colNum = 0;
	            	if (rowNum <= 49) {
	            		rowNum++;
	            	}
	            }
	         }
	         catch (EOFException e)
	         {
	            endOfFile = true;
	         }
	         inputFile.close();
	      } */
		
		for(int i=0; i<50; i++) {
			for(int j=0; j<2; j++) {
				current = inputFile.readUTF();
				statesBinFile[rowNum][colNum] = current;
				if(colNum == 0) {
	            	colNum++;
	            } else if (colNum == 1){
	            	colNum = 0;
	            	if (rowNum <= 49) {
	            		rowNum++;
	            	}
	            }
			}
		}
		inputFile.close();
		return statesBinFile;
	}
	
	public static String getState(String[][] states) throws CancelledSurveyException, IOException {
		boolean validState = false;
		String state = "";
		
		while(!validState) {
			try {
				System.out.print("Please enter the 2-letter state abbreviation: ");
				String response = getResponseOrQuit();
				for(int row=0; row<=49; row++) {
					if (states[row][0].equals(response)) {
						state = states[row][1];
						validState = true;
					}
				}
				if (!validState) {
					System.out.println("The state abbreviation was not found.");
				}
			}
			catch(IllegalArgumentException e) {
				System.out.println("The state abbreviation was not found.");
			}
		}
		return state;
	}

}
