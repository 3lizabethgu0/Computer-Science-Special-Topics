// Elizabeth Guo
package rectangraphic;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class RectanGraphic {
	public static void main(String[] args) throws IOException {
		Scanner reader = new Scanner(new FileReader("rectangles.txt"));
		while(reader.hasNext()) {
			int rows = reader.nextInt();
			int cols = reader.nextInt();
			boolean filled = false;
				
			if (reader.next().equals("filled")) {
				filled = true;
			}
				
			Rectangle rect = new Rectangle(rows, cols, filled);
			System.out.println(rect.toString());
		}
		reader.close();
	}
}
