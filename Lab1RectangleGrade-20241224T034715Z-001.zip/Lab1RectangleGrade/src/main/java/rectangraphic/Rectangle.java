// Elizabeth Guo
package rectangraphic;

public class Rectangle {
	private int rows;
	private int cols;
	private boolean filled;
	
	public Rectangle(int rows, int cols, boolean filled) {
		this.rows = rows;
		this.cols = cols;
		this.filled = filled;
	}
	
	public String toString() {
		String result = "";
		if (filled == true) {
			for(int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					result = result + "#";
				}
				result = result + "\n";
			}
		} else if (filled == false) {
			for(int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					if (i == 0 || i == rows-1) {
						result = result + "#";
					} else if (j == 0 || j == cols-1 ) {
						result = result + "#";
					} else {
						result = result + " ";
					}
				}
				result = result + "\n";
			}
		}
		return result;
	}
}