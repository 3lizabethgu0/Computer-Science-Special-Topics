// Elizabeth Guo
package gradebook;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class GradeBook {
	public static void main(String[] args) throws IOException {
		Scanner reader = new Scanner(new FileReader("grade_data.txt"));
		int numStudents = reader.nextInt();
		double totalAverage = 0.0;
		Student[] Students = new Student[numStudents];
		System.out.println("Student\tTest1\tTest2\tTest3\tTest4\tTest5\tAverage\tGrade\n");
		int i = 0;
		while(reader.hasNext()) {
			String name = reader.next();
			int score1 = reader.nextInt();
			int score2 = reader.nextInt();
			int score3 = reader.nextInt();
			int score4 = reader.nextInt();
			int score5 = reader.nextInt();
			Student student = new Student(name, score1, score2, score3, score4, score5);
			totalAverage += student.getAverage();
			Students[i] = student;
			i++;
		}
		for(int j=0; j<numStudents; j++) {
			System.out.println(Students[j]);
		}
		System.out.println("\nClass Average = " + totalAverage/numStudents);
	}
}
