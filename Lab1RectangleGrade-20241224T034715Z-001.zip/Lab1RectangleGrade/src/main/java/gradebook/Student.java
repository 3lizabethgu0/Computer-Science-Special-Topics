// Elizabeth Guo
package gradebook;

public class Student {
	private String name;
	private int[] scores = new int[5];
	
	public Student(String name, int score1, int score2, int score3, int score4, int score5) {
		this.name = name;
		this.scores[0] = score1;
		this.scores[1] = score2;
		this.scores[2] = score3;
		this.scores[3] = score4;
		this.scores[4] = score5;
	}
	
	public double getAverage() {
		int total = 0;
		for (int i = 0; i < 5; i++) {
			total += scores[i];
		}
		return total/5.0;
	}
	
	public String getGrade() {
		if (getAverage() < 60) {
			return "F";
		} else if (getAverage() < 70) {
			return "D";
		} else if (getAverage() < 80) {
			return "C";
		} else if (getAverage() < 90) {
			return "B";
		} else {
			return "A";
		}
	}
	
	public String toString() {
		String result = name + "\t";
		for (int i = 0; i < 5; i++) {
			result += scores[i];
			result += "\t";
		}
		result += getAverage();
		result += "\t";
		result += getGrade();
		return result;
	}
}