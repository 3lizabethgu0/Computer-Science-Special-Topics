package car;

public class NewCar extends Car{
	private double optionsCost;
	private double rebate;
	
	private static int newCarCount;
	private static double newCarTotalAssets;
	
	public NewCar(String id, int year, double price, double commission, double options, double rebate) {
		super(id, year, price, commission);
	    this.optionsCost = options;
	    this.rebate = rebate;
	    newCarCount += 1;
	}
	
	public double getOptions() {
    	return optionsCost;
    }
    
    public void setOptions(double newOptions) {
    	optionsCost = newOptions;
    }
    
    public double getRebate() {
    	return rebate;
    }
    
    public void setRebate(double newRebate) {
    	rebate = newRebate;
    }
    
    public static double getTotalAssets() {
    	return newCarTotalAssets;
    }
    
    public static int getTotalCars() {
    	return newCarCount;
    }
    
    public double computeTotal() {
    	double totalCost1 = basePrice + optionsCost + commission;
    	double totalCost2 = totalCost1 - rebate;
    	return totalCost2;
    }
    
    public void updateAssets() {
    	totalAssets += computeTotal();
    	newCarTotalAssets += computeTotal();
    }
    
    public double getMileage() {
    	return 0.;
    }
    
    public boolean goodBusiness() {
    	if(commission > (0.08 * basePrice)) {
    		return true;
    	}
    	return false;
    }
    
    public String toString() {
    	String businessStatus = "";
    	if(goodBusiness() == true) {
    		businessStatus = "Good";
    	} else if(goodBusiness() == false) {
    		businessStatus = "Bad";
    	}
    	return "New Car\n" + super.toString() + "\nOption Cost = " + optionsCost + "\nRebate = " + rebate + "\nTotal cost = " + computeTotal() + "\nDeal = " + businessStatus;
    }
}
