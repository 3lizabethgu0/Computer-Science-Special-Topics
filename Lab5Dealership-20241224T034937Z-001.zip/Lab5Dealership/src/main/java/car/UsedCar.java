package car;

public class UsedCar extends Car{
	private double mileage;
	private double rateOfDepreciation;
	
	private static int usedCarCount;
	private static double usedCarTotalAssets;
	
	public UsedCar(String id, int year, double price, double commission, double mileage, double depRate) {
		super(id, year, price, commission);
		this.mileage = mileage;
		rateOfDepreciation = depRate;
		usedCarCount += 1;
	}
	
	public double getMileage() {
		return mileage;
	}
	
	public void setMileage(double newMileage) {
		mileage = newMileage;
	}
	
	public double getDepRate() {
		return rateOfDepreciation;
	}
	
	public void setDepRate(double newDepRate) {
		rateOfDepreciation = newDepRate;
	}
	
	public static double getTotalAssets() {
		return usedCarTotalAssets;
	}
	
	public static int getTotalCars() {
		return usedCarCount;
	}
	
	public double computeTotal() {
		double totalCost1 = mileage * rateOfDepreciation;
		double totalCost2 = basePrice - totalCost1;
		double totalCost3 = totalCost2 + commission;
		return totalCost3;
	}
	
	public void updateAssets() {
		totalAssets += computeTotal();
		usedCarTotalAssets += computeTotal();
	}
	
	public boolean goodBusiness() {
		if(commission > (0.04 * computeTotal())) {
			return true;
		}
		return false;
	}
	
	public String toString() {
		String businessStatus = "";
    	if(goodBusiness() == true) {
    		businessStatus = "Good";
    	} else if(goodBusiness() == false) {
    		businessStatus = "Bad";
    	}
		return "Used Car\n" + super.toString() + "\nMileage = " + mileage + "\nRate of Depreciation = " + rateOfDepreciation + "\nTotal Cost = " + computeTotal() + "\nDeal = " + businessStatus;
	}
	
}
