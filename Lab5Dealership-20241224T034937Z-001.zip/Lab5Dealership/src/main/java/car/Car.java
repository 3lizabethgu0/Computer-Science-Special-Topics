package car;

public abstract class Car {
	private String id;
	private int year;
	
	protected double basePrice;
	protected double commission;
	
	protected static double totalAssets;
	
	public Car(String id, int year, double price, double commission){
		this.id = id;
		this.year = year;
		this.basePrice = price;
		this.commission = commission;
	}
	
	public void setID(String newID) {
		id = newID;
	}
	
	public String getID() {
		return id;
	}
	
	public void setYear(int newYear) {
		year = newYear;
	}
	
	public int getYear() {
		return year;
	}
	
	public static double getTotalAssets() {
		return totalAssets;
	}
	
	public String toString() {
		return "Vihicle ID = " + id + "\nModel year = " + year + "\nBase price = " + basePrice + "\nCommission = " + commission;
	}
	
	public abstract void updateAssets();
	public abstract double getMileage();
	public abstract boolean goodBusiness();
}
