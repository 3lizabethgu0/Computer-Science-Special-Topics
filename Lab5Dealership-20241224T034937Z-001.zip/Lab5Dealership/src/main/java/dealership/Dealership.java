package dealership;

import car.*;

public class Dealership {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Car[] carInventory = new Car[6];
		
		carInventory[0] = new NewCar("N2312", 2006, 18000, 2000, 3000, 2000);
		carInventory[2] = new NewCar("N6467", 2006, 43000, 4000, 6000, 3000);
		carInventory[4] = new NewCar("N0864", 2007, 24000, 1200, 2500, 0);
		
		carInventory[1] = new UsedCar("U3425", 2003, 16000, 400, 40000, 0.15);
		carInventory[3] = new UsedCar("U2347", 1998, 8000, 700, 12000, 0.1);
		carInventory[5] = new UsedCar("U4739", 2005, 18000, 2400, 12000, 0.2);
		
		for(int i=0; i<6; i++) {
			carInventory[i].updateAssets();
		}
		
		System.out.print("Total Assets of Dealer = " + Car.getTotalAssets() + "\n\nTotal Assets of NewCar = " + NewCar.getTotalAssets() + "\nAverage New Car Price = " + NewCar.getTotalAssets()/NewCar.getTotalCars() + "\n\nTotal Assets of UsedCar = " + UsedCar.getTotalAssets() + "\nAverage Used Car Price = " + String.format("%.3f", UsedCar.getTotalAssets()/UsedCar.getTotalCars()) + "\n\n");
		
		for (int i=0; i<6; i++) {
			System.out.println(carInventory[i].toString());
			System.out.println();
		}
	}

}