package lab;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * Name: Elizabeth Guo
 * Username: elizabethguo
 */

public class Controller {
	@FXML
    private Button convert;
	@FXML
	private Button clear;
	@FXML
	private Button exit;
	@FXML
	private TextField cmT;
	@FXML
	private TextField inT;
	@FXML
	private TextField yT;
	@FXML
	private TextField mT;
	@FXML
	private Label errorL;
	
	public void convert() {
		errorL.setVisible(false);
		int fieldsFilled = 0;
		if (cmT.getText().isEmpty() == false) {
			fieldsFilled++;
		}
		if (inT.getText().isEmpty() == false) {
			fieldsFilled++;
		}
		if (yT.getText().isEmpty() == false) {
			fieldsFilled++;
		}
		if (mT.getText().isEmpty() == false) {
			fieldsFilled++;
		}
		if (fieldsFilled > 1) {
			errorL.setVisible(true);
		} else if (cmT.getText().isEmpty() == false) {
			cmConvert();
		} else if (inT.getText().isEmpty() == false) {
			inConvert();
		} else if (yT.getText().isEmpty() == false) {
			yConvert();
		} else if (mT.getText().isEmpty() == false) {
			mConvert();
		}
	}
	
	public void cmConvert() {
		double cmTInput = Double.parseDouble(cmT.getText());
		mT.setText(String.format("%.2f", cm2m(cmTInput)));
		yT.setText(String.format("%.2f", cm2y(cmTInput)));
		inT.setText(String.format("%.2f", cm2in(cmTInput)));
	}
	
	public void inConvert() {
		double inTInput = Double.parseDouble(inT.getText());
		mT.setText(String.format("%.2f", in2m(inTInput)));
		yT.setText(String.format("%.2f", in2y(inTInput)));
		cmT.setText(String.format("%.2f", in2cm(inTInput)));
	}
	
	public void yConvert() {
		double yTInput = Double.parseDouble(yT.getText());
		mT.setText(String.format("%.2f", y2m(yTInput)));
		inT.setText(String.format("%.2f", y2in(yTInput)));
		cmT.setText(String.format("%.2f", y2cm(yTInput)));
	}
	
	public void mConvert() {
		double mTInput = Double.parseDouble(mT.getText());
		yT.setText(String.format("%.2f", m2y(mTInput)));
		inT.setText(String.format("%.2f", m2in(mTInput)));
		cmT.setText(String.format("%.2f", m2cm(mTInput)));
	}
	
	public static double cm2in(double cmTInput) {
		double solution = cmTInput * 0.393701;
		return(solution);
	}
	
	public static double cm2m(double cmTInput) {
		double solution = cmTInput * 0.01;
		return(solution);
	}
	
	public static double cm2y(double cmTInput) {
		double solution = cmTInput * 0.0109361;
		return(solution);
	}
	
	public static double in2cm(double inTInput) {
		double solution = inTInput * 2.54;
		return(solution);
	}
	
	public static double in2y(double inTInput) {
		double solution = inTInput * 0.0277778;
		return(solution);
	}
	
	public static double in2m(double inTInput) {
		double solution = inTInput * 0.0254;
		return(solution);
	}
	
	public static double y2m(double yTInput) {
		double solution = yTInput * 0.9144;
		return(solution);
	}
	
	public static double y2in(double yTInput) {
		double solution = yTInput * 36;
		return(solution);
	}
	
	public static double y2cm(double yTInput) {
		double solution = yTInput * 91.44;
		return(solution);
	}
	
	public static double m2y(double mTInput) {
		double solution = mTInput * 1.09361;
		return(solution);
	}
	
	public static double m2in(double mTInput) {
		double solution = mTInput * 39.3701;
		return(solution);
	}
	
	public static double m2cm(double mTInput) {
		double solution = mTInput * 100;
		return(solution);
	}
	
	public void clear() {
		inT.setText("");
		yT.setText("");
		cmT.setText("");
		mT.setText("");
	}
	
	public void exit() {
		System.exit(0);
	}
}