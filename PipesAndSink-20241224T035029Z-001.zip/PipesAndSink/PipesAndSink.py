import pygame

with open("input.txt", encoding="utf-8") as file:
    data = file.read().split("\n\n")

for i, line in enumerate(data):
     data[i] = line.split(" ")
     data[i][1] = int(data[i][1])
     data[i][2] = int(data[i][2])

matrix = [[" " for _ in range(50)] for _ in range(30)]
for symbol, col, row in data:
    matrix[29-row][col]=symbol
    if symbol == "*":
         sourceX = col
         sourceY = 29-row

for row in matrix:
    print("".join(row))

print()  

pipes = ["═", "║", "╔", "╗", "╚", "╝", "╠", "╣", "╦", "╩"]
connected = []
solution = []
visited = []

WIDTH, HEIGHT = 1000, 600
ROWS = 30
COLS = 50
CELL_SIZE = 20

pipeTypes = {
    # top, bottom, right, left
    "═": [False, False, True, True],
    "║": [True, True, False, False],
    "╔": [False, True, True, False],
    "╗": [False, True, False, True],
    "╚": [True, False, True, False],
    "╝": [True, False, False, True],
    "╠": [True, True, True, False],
    "╣": [True, True, False, True],
    "╦": [False, True, True, True],
    "╩": [True, False, True, True]
}

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PASTEL_BLUE = (179, 235, 242)
PASTEL_RED = (255, 116, 108)

def isPipe(char):
    if char in pipes:
        return True
    else:
        return False
    
def checkPipe(currentX, currentY):
        
    if currentY != 0: 
        if isPipe(matrix[currentY-1][currentX]):
            if (matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][0]) and pipeTypes[matrix[currentY-1][currentX]][1]:
                if (currentY-1, currentX) not in visited:
                    connected.append(matrix[currentY-1][currentX])
                    visited.append((currentY-1, currentX))
                    checkPipe(currentX, currentY-1)
        elif matrix[currentY-1][currentX].isalpha():
            if matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][0]:
                if (currentY-1, currentX) not in visited:
                    connected.append(matrix[currentY-1][currentX])
                    visited.append((currentY-1, currentX))
                    checkPipe(currentX, currentY-1)

    if currentY != len(matrix)-1:  
        if isPipe(matrix[currentY+1][currentX]):
            if (matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][1]) and pipeTypes[matrix[currentY+1][currentX]][0]:
                if (currentY+1, currentX) not in visited:
                    connected.append(matrix[currentY+1][currentX])
                    visited.append((currentY+1, currentX))
                    checkPipe(currentX, currentY+1)
        elif matrix[currentY+1][currentX].isalpha():
            if matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][1]:
                if (currentY+1, currentX) not in visited:
                    connected.append(matrix[currentY+1][currentX])
                    visited.append((currentY+1, currentX))
                    checkPipe(currentX, currentY+1)

    if currentX != len(matrix[0])-1:
        if isPipe(matrix[currentY][currentX+1]):
            if (matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][2]) and pipeTypes[matrix[currentY][currentX+1]][3]:
                if (currentY, currentX+1) not in visited:
                    connected.append(matrix[currentY][currentX+1])
                    visited.append((currentY, currentX+1))
                    checkPipe(currentX+1, currentY)
        elif matrix[currentY][currentX+1].isalpha():
            if matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][2]:
                if (currentY, currentX+1) not in visited:
                    connected.append(matrix[currentY][currentX+1])
                    visited.append((currentY, currentX+1))
                    checkPipe(currentX+1, currentY)

    if currentX != 0:
        if isPipe(matrix[currentY][currentX-1]):
            if (matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][3]) and pipeTypes[matrix[currentY][currentX-1]][2]:
                if (currentY, currentX-1) not in visited:
                    connected.append(matrix[currentY][currentX-1])
                    visited.append((currentY, currentX-1))
                    checkPipe(currentX-1, currentY)
        elif matrix[currentY][currentX-1].isalpha():
            if matrix[currentY][currentX] == "*" or matrix[currentY][currentX].isalpha() or pipeTypes[matrix[currentY][currentX]][3]:
                if (currentY, currentX-1) not in visited:
                    connected.append(matrix[currentY][currentX-1])
                    visited.append((currentY, currentX-1))
                    checkPipe(currentX-1, currentY)

def drawPipe(screen, row, col, x, y):
    pipeColor = BLACK
    if (row, col) in visited:
        if matrix[row][col].isalpha():
            pipeColor = PASTEL_RED
        else:
            pygame.draw.rect(screen, PASTEL_BLUE, (x, y, CELL_SIZE, CELL_SIZE))
    if matrix[row][col] == "═":
        pygame.draw.line(screen, pipeColor, (x, y + CELL_SIZE // 2), (x + CELL_SIZE, y + CELL_SIZE // 2), 5)
    elif matrix[row][col] == "║":
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y), (x + CELL_SIZE // 2, y + CELL_SIZE), 5)
    elif matrix[row][col] == "╔":
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE // 2), (x + CELL_SIZE, y + CELL_SIZE // 2), 5)
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE //2), (x + CELL_SIZE // 2, y + CELL_SIZE), 5)
    elif matrix[row][col] == "╗":
        pygame.draw.line(screen, pipeColor, (x, y + CELL_SIZE // 2), (x + CELL_SIZE // 2, y + CELL_SIZE // 2), 5)
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE // 2), (x + CELL_SIZE // 2, y + CELL_SIZE), 5)
    elif matrix[row][col] == "╚":
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y), (x + CELL_SIZE // 2, y + CELL_SIZE // 2), 5)
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE // 2), (x + CELL_SIZE, y + CELL_SIZE //2), 5)
    elif matrix[row][col] == "╝":
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y), (x + CELL_SIZE // 2, y + CELL_SIZE // 2), 5)
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE // 2), (x, y + CELL_SIZE // 2), 5)
    elif matrix[row][col] == "╠":
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y), (x + CELL_SIZE // 2, y + CELL_SIZE), 5)
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE // 2), (x + CELL_SIZE, y + CELL_SIZE // 2), 5)
    elif matrix[row][col] == "╣":
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y), (x + CELL_SIZE // 2, y + CELL_SIZE), 5)
        pygame.draw.line(screen, pipeColor, (x, y + CELL_SIZE // 2), (x + CELL_SIZE // 2, y + CELL_SIZE // 2), 5)
    elif matrix[row][col] == "╦":
        pygame.draw.line(screen, pipeColor, (x, y + CELL_SIZE // 2), (x + CELL_SIZE, y + CELL_SIZE // 2), 5)
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE // 2), (x + CELL_SIZE // 2, y + CELL_SIZE), 5)
    elif matrix[row][col] == "╩":
        pygame.draw.line(screen, pipeColor, (x + CELL_SIZE // 2, y), (x + CELL_SIZE // 2, y + CELL_SIZE // 2), 5)
        pygame.draw.line(screen, pipeColor, (x, y + CELL_SIZE // 2), (x + CELL_SIZE, y + CELL_SIZE // 2), 5)
    elif matrix[row][col] == "*":
        pygame.draw.circle(screen, pipeColor, (x + CELL_SIZE // 2, y + CELL_SIZE // 2), CELL_SIZE // 3)
    elif matrix[row][col].isalpha(): 
        font = pygame.font.SysFont(None, 30)
        text = font.render(matrix[row][col], True, pipeColor)
        screen.blit(text, (x + CELL_SIZE // 4, y + CELL_SIZE // 4))

checkPipe(sourceX, sourceY)

for i in connected:
    if i.isalpha():
            solution.append(i)

sortedSolution = sorted(solution)
print(sortedSolution)   

def main():
    pygame.display.init()
    pygame.font.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Pipe Maze Visualization")
    running = True

    while running:
        screen.fill(WHITE)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        for row in range(len(matrix)):
            for col in range(len(matrix[row])):
                x = col * CELL_SIZE
                y = row * CELL_SIZE
                drawPipe(screen, row, col, x, y)
        pygame.display.flip()
    pygame.quit()

if __name__ == "__main__":
    main() 
