/*
	Name: Elizabeth Guo
	Username: elizabethguo
*/
import java.util.*;

public class Hero {
	private String name;
	private String role;
	private int level;
	private int experience;
	private static final int MAX_level = 100;
	String[] ROLES = {"Warrior", "Priest", "Wizard", "Thief"};
	
	public Hero(String name) {
		this.name = name;
		role = "Unassigned";
		level = 1;
		experience = 0;
	}
	
	public void setRole(String role) {
		boolean allowedRole = false;
		for(int i=0; i<4; i++) {
			if(role == ROLES[i]) {
				allowedRole = true;
			}
		}
		if(allowedRole == true) {
			this.role = role;
		} else if(allowedRole == false) {
			this.role = "Unassigned";
			System.out.println("Invalid role");
		}
	}
	
	public String getName() {
		return name;
	}
	
	public String getRole() {
		return role;
	}
	
	public int getLevel() {
		return level;
	}
	
	public int getExperience() {
		return experience;
	}
	
	public int expToLevelUp() {
		return (int)Math.pow(level, 2);
	}
	
	public void gainExperience(int experience) {
		this.experience += experience;
		while (this.experience >= expToLevelUp() && level < 100) {
			this.experience -= expToLevelUp();
			level++;
			System.out.println(name + " is now level " + level + "!");
		}
	}

	public String toString() {
		return (name + " the " + role + " is level " + level + " with " + experience + " experience.");
	}
}
