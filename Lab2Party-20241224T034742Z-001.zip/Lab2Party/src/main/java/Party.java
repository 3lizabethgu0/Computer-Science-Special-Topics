/*
	Name: Elizabeth Guo
	Username: elizabethguo
*/

public class Party {
	Hero[] heroes = new Hero[3];
	
	public Party() {
		for (int i=0; i<3; i++) {
			heroes[i] = null;
		}
	}
	
	public void addHero(Hero hero, int index) {
		boolean alreadyinParty = false;
		for (int i=0; i<3; i++) {
			if (heroes[i] == hero) {
				alreadyinParty = true;
			}
		}
		if (alreadyinParty == false) {
			heroes[index] = hero;
		} else if (alreadyinParty == true) {
			System.out.println(hero.getName() + " is already in the party.");
		}
	}
	
	public void removeHero(int index) {
		heroes[index] = null;
	}
	
	public Hero getHero(int index) {
		return heroes[index];
	}
	
	public void gainExperience(int experience) {
		System.out.println("The party gained " + experience + " experience.");
		for (int i=0; i<3; i++) {
			if(heroes[i] != null) {
				heroes[i].gainExperience(experience);
			}
		}
	}
	
	public String toString() {
		String returnValue = "Party:\n";
		for (int i=0; i<3; i++) {
			if (heroes[i] != null) {
				returnValue += heroes[i].toString();
				returnValue += "\n";
			}
		}
		return returnValue;
	}
}
 