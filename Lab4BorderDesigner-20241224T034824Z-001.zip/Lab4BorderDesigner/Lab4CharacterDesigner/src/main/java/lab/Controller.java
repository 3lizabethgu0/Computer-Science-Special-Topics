package lab;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

public class Controller {

	@FXML
    private ToggleGroup backgroundColors;

    @FXML
    private VBox bottomBox;

    @FXML
    private Label bottomText;

    @FXML
    private RadioButton cyanButt;

    @FXML
    private CheckBox eastCheck;

    @FXML
    private TextField fourWords;

    @FXML
    private RadioButton greenButt;

    @FXML
    private VBox leftBox;

    @FXML
    private Label leftText;

    @FXML
    private CheckBox northCheck;

    @FXML
    private RadioButton orangeButt;

    @FXML
    private VBox rightBox;

    @FXML
    private Label rightText;

    @FXML
    private RadioButton salmonButt;

    @FXML
    private CheckBox southCheck;

    @FXML
    private VBox topBox;

    @FXML
    private Label topText;

    @FXML
    private CheckBox westCheck;


    @FXML
    void colorChange(ActionEvent event) {
    	
    	if(event.getSource() == salmonButt) {
    		if(northCheck.isSelected()) {
    			topBox.setStyle("-fx-background-color: Salmon");
    		}
    		if(southCheck.isSelected()) {
    			bottomBox.setStyle("-fx-background-color: Salmon");
    		}
    		if(eastCheck.isSelected()) {
    			rightBox.setStyle("-fx-background-color: Salmon");
    		}
    		if(westCheck.isSelected()) {
    			leftBox.setStyle("-fx-background-color: Salmon");
    		}
    	}
    	if(event.getSource() == greenButt) {
    		if(northCheck.isSelected()) {
    			topBox.setStyle("-fx-background-color: SpringGreen");
    		}
    		if(southCheck.isSelected()) {
    			bottomBox.setStyle("-fx-background-color: SpringGreen");
    		}
    		if(eastCheck.isSelected()) {
    			rightBox.setStyle("-fx-background-color: SpringGreen");
    		}
    		if(westCheck.isSelected()) {
    			leftBox.setStyle("-fx-background-color: SpringGreen");
    		}
    	}
    	if(event.getSource() == orangeButt) {
    		if(northCheck.isSelected()) {
    			topBox.setStyle("-fx-background-color: Orange");
    		}
    		if(southCheck.isSelected()) {
    			bottomBox.setStyle("-fx-background-color: Orange");
    		}
    		if(eastCheck.isSelected()) {
    			rightBox.setStyle("-fx-background-color: Orange");
    		}
    		if(westCheck.isSelected()) {
    			leftBox.setStyle("-fx-background-color: Orange");
    		}
    	}
    	if(event.getSource() == cyanButt) {
    		if(northCheck.isSelected()) {
    			topBox.setStyle("-fx-background-color: Cyan");
    		}
    		if(southCheck.isSelected()) {
    			bottomBox.setStyle("-fx-background-color: Cyan");
    		}
    		if(eastCheck.isSelected()) {
    			rightBox.setStyle("-fx-background-color: Cyan");
    		}
    		if(westCheck.isSelected()) {
    			leftBox.setStyle("-fx-background-color: Cyan");
    		}
    	}
    	
    }

    @FXML
    void diverge(ActionEvent event) {
    	
    	String[] wordsArray = fourWords.getText().split(" ");
    	
    	if(wordsArray.length != 4) {
    		fourWords.setPromptText("Please enter exactly 4 words");
    		fourWords.setText("");
    	} else if(wordsArray.length == 4) {
    		topText.setText(wordsArray[0]);
    		rightText.setText(wordsArray[1]);
    		bottomText.setText(wordsArray[2]);
    		leftText.setText(wordsArray[3]);
    	}
    	
    }

}